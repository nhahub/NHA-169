import pandas as pd
from sklearn.preprocessing import LabelEncoder, MinMaxScaler
from sklearn.model_selection import train_test_split

def preprocess_student_data(df: pd.DataFrame, target_col='pass_fail', test_size=0.2, random_state=42):
    data = df.copy()
    print("🚀 Starting preprocessing...")
    print(f"Initial shape: {data.shape}")

    # 1️⃣ Drop name & date columns
    drop_cols = ['first_name', 'last_name', 'evaluation_date']
    data.drop(columns=drop_cols, inplace=True, errors='ignore')
    print(f"✅ Dropped columns: {drop_cols}")

    # 2️⃣ Separate target
    y = data[target_col].copy()
    X = data.drop(columns=[target_col])

    # 3️⃣ Encode categorical columns
    cat_cols = X.select_dtypes(include='object').columns
    print(f"🔹 Encoding categorical columns: {list(cat_cols)}")

    le = LabelEncoder()
    for col in cat_cols:
        X[col] = le.fit_transform(X[col].astype(str))

    # 4️⃣ Scale numeric features
    scaler = MinMaxScaler()
    X_scaled = pd.DataFrame(scaler.fit_transform(X), columns=X.columns)

    # 5️⃣ Encode target column
    y_encoded = LabelEncoder().fit_transform(y)

    # 6️⃣ Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X_scaled, y_encoded, test_size=test_size, random_state=random_state, stratify=y_encoded
    )

    print("🎯 Preprocessing & Split done!")
    print(f"Train shape: {X_train.shape}, Test shape: {X_test.shape}")

    return X_train, X_test, y_train, y_test
