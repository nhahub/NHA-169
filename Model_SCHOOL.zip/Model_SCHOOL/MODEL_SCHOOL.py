from sklearn.model_selection import GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report
import warnings
warnings.filterwarnings('ignore')

try:
    from xgboost import XGBClassifier
    xgb_available = True
except ImportError:
    xgb_available = False
    print("⚠️ XGBoost not installed. Skipping XGBClassifier.")


def train_light_gridsearch(X_train, X_test, y_train, y_test):
    print("🚀 Starting Light Grid Search (≈10 models total)...")

    results = {}

    # ==================================================
    # 1️⃣ Logistic Regression (3 combinations × cv=3 = 9 runs)
    # ==================================================
    print("\n🔹 Logistic Regression (light tuning)...")
    log_reg = LogisticRegression(max_iter=1000)
    log_params = {
        'C': [0.1, 1, 10],
        'solver': ['liblinear']  # ثابت
    }

    grid_log = GridSearchCV(log_reg, log_params, cv=3, scoring='accuracy', n_jobs=-1)
    grid_log.fit(X_train, y_train)
    best_log = grid_log.best_estimator_
    y_pred_log = best_log.predict(X_test)
    acc_log = accuracy_score(y_test, y_pred_log)
    print(f"✅ Best Params: {grid_log.best_params_}")
    print(f"📊 Accuracy: {acc_log:.4f}")
    results['Logistic Regression'] = acc_log


    # ==================================================
    # 2️⃣ Random Forest (3 combinations × cv=3 = 9 runs)
    # ==================================================
    print("\n🔹 Random Forest (light tuning)...")
    rf = RandomForestClassifier(random_state=42)
    rf_params = {
        'n_estimators': [100, 200],
        'max_depth': [10],
        'min_samples_split': [2]
    }

    grid_rf = GridSearchCV(rf, rf_params, cv=3, scoring='accuracy', n_jobs=-1)
    grid_rf.fit(X_train, y_train)
    best_rf = grid_rf.best_estimator_
    y_pred_rf = best_rf.predict(X_test)
    acc_rf = accuracy_score(y_test, y_pred_rf)
    print(f"✅ Best Params: {grid_rf.best_params_}")
    print(f"📊 Accuracy: {acc_rf:.4f}")
    results['Random Forest'] = acc_rf


    # ==================================================
    # 3️⃣ XGBoost (اختياري - 3 combinations × cv=3 = 9 runs)
    # ==================================================
    if xgb_available:
        print("\n🔹 XGBoost (light tuning)...")
        xgb = XGBClassifier(use_label_encoder=False, eval_metric='logloss', random_state=42)
        xgb_params = {
            'n_estimators': [100, 200],
            'max_depth': [5],
            'learning_rate': [0.1]
        }

        grid_xgb = GridSearchCV(xgb, xgb_params, cv=3, scoring='accuracy', n_jobs=-1)
        grid_xgb.fit(X_train, y_train)
        best_xgb = grid_xgb.best_estimator_
        y_pred_xgb = best_xgb.predict(X_test)
        acc_xgb = accuracy_score(y_test, y_pred_xgb)
        print(f"✅ Best Params: {grid_xgb.best_params_}")
        print(f"📊 Accuracy: {acc_xgb:.4f}")
        results['XGBoost'] = acc_xgb
    else:
        print("⚠️ XGBoost not available. Skipping it.")

    # ==================================================
    # 🏆 Summary
    # ==================================================
    print("\n🎯 Summary of Results:")
    for name, acc in results.items():
        print(f"{name}: {acc:.4f}")

    best_model = max(results, key=results.get)
    print(f"\n🏆 Best Model: {best_model} (Accuracy = {results[best_model]:.4f})")

    return results
